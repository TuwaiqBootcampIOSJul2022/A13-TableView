//
//  ViewController.swift
//  sortedBookStore
//
//  Created by KhalidAteeq on 28/01/1444 AH.
//

import UIKit

class ViewController: UIViewController {
    struct Product{
        
        var name:String
        var author:String
        var discrp:String
        var price:Int
        var category:String
        var image:String
        var shortSummry:String
    }
    var book1 = Product.init(name: "End of Camelot‎", author:"Bill O'Reilly", discrp: "ledearship", price: 45, category: "Investigation", image: "End of Camelot‎", shortSummry:"With Sen. Edward Kennedy’s death comes not only the end of a political dynasty, but also of one of the most enduring — and cherished — American myths. Camelot is no more.")
    var book2 = Product.init(name: "Elon Musk‎", author: "‎Ashlee Vance", discrp:"Speaking skills", price: 61, category: "Learning", image: "Elon Musk‎", shortSummry:"“Elon Reeve Musk FRS (/ˈiːlɒn/ EE-lon; born June 28, 1971) is a naturalized American business magnate and investor. He is the founder, CEO, and Chief Engineer at SpaceX; angel investor, CEO, and Product Architect of Tesla, Inc.; founder of The Boring Company; and co-founder of Neuralink and OpenAI. With an estimated net worth of around US$266 billion as of August 17, 2022,[4] Musk is the wealthiest person in the world according to both the Bloomberg Billionaires Index and Forbes' real-time billionaires list.”")
    var book3 = Product.init(name: "Steve Jobs‎", author: "Walter Isaacson", discrp:"Think like tyrant", price: 105, category: "History", image: "Steve Jobs‎", shortSummry:"Steven Paul Jobs (February 24, 1955 – October 5, 2011) was an American entrepreneur, industrial designer, business magnate, media proprietor, and investor. He was the co-founder, chairman, and CEO of Apple; the chairman and majority shareholder of Pixar; a member of The Walt Disney Company's board of directors following its acquisition of Pixar; and the founder, chairman, and CEO of NeXT. He is widely recognized as a pioneer of the personal computer revolution of the 1970s and 1980s, along with his early business partner and fellow Apple co-founder Steve Wozniak.")
//    let allBooks = [book1 , book2 , book3]
    var books:Array<Product> = [Product.init(name: "End of Camelot‎", author:"Bill O'Reilly", discrp: "ledearship", price: 45, category: "Investigation", image: "End of Camelot‎", shortSummry:"With Sen. Edward Kennedy’s death comes not only the end of a political dynasty, but also of one of the most enduring — and cherished — American myths. Camelot is no more."),Product.init(name: "Elon Musk‎", author: "‎Ashlee Vance", discrp:"Speaking skills", price: 61, category: "Learning", image: "Elon Musk‎", shortSummry:"“Elon Reeve Musk FRS (/ˈiːlɒn/ EE-lon; born June 28, 1971) is a naturalized American business magnate and investor. He is the founder, CEO, and Chief Engineer at SpaceX; angel investor, CEO, and Product Architect of Tesla, Inc.; founder of The Boring Company; and co-founder of Neuralink and OpenAI. With an estimated net worth of around US$266 billion as of August 17, 2022,[4] Musk is the wealthiest person in the world according to both the Bloomberg Billionaires Index and Forbes' real-time billionaires list.”"),Product.init(name: "Steve Jobs‎", author: "Walter Isaacson", discrp:"Think like tyrant", price: 105, category: "History", image: "Steve Jobs‎", shortSummry:"Steven Paul Jobs (February 24, 1955 – October 5, 2011) was an American entrepreneur, industrial designer, business magnate, media proprietor, and investor. He was the co-founder, chairman, and CEO of Apple; the chairman and majority shareholder of Pixar; a member of The Walt Disney Company's board of directors following its acquisition of Pixar; and the founder, chairman, and CEO of NeXT. He is widely recognized as a pioneer of the personal computer revolution of the 1970s and 1980s, along with his early business partner and fellow Apple co-founder Steve Wozniak."),Product.init(name: "MyStruggle", author: "Adlof Hitler", discrp:"Think like tyrant", price: 120, category: "History", image: "MyStruggle", shortSummry:"It treats the world of Hitler's youth, the First World War, and the “betrayal” of Germany's collapse in 1918; it also expresses Hitler's racist ideology, identifying the Aryan as the “genius” race and the Jew as the “parasite,” and declares the need for Germans to seek living space (Lebensraum) in the East at the")]


    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableViewinMain: UITableView!
    var filterData:[Product]!
    var sendimagefrom = ""
    var sendSummaryfrom = ""
    var sendNamefrom = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        filterData = books
        tableViewinMain.dataSource = self
        tableViewinMain.delegate = self
        tableViewinMain.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "Cells")
        searchBar.delegate = self
        view.backgroundColor = .lightGray
//        sortTable()
    }
    @IBAction func sortedSegment(_ sender: UISegmentedControl) {
        let selecteSender = sender.selectedSegmentIndex
        
        switch selecteSender {
        case 0:
            filterData.sort(by: {$0.price < $1.price})
        case 1:
            filterData.sort(by: {$0.price > $1.price})
        default:
            break
        }
        tableViewinMain.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as! TableViewCell
        cell.cellImage.image = UIImage(named: "\(filterData[indexPath.row].image)")
        cell.cellPrice.text = "Price: \(filterData[indexPath.row].price)"
        cell.cellname.text = "Name: \(filterData[indexPath.row].name)"
        cell.cellInterest.text = "Interest: \(filterData[indexPath.row].category)"
        cell.celltitle.text = "Author: \(filterData[indexPath.row].author)"
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showResult"{
            if let send = segue.destination as? secondViewController {
                send.sendimage = sendimagefrom
                send.sendName = sendNamefrom
                send.sendSummry = sendSummaryfrom
            }
        }
    }
    

    
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        sendimagefrom = filterData[indexPath.row].image
        sendNamefrom = filterData[indexPath.row].name
        sendSummaryfrom = filterData[indexPath.row].shortSummry
        performSegue(withIdentifier: "showResult", sender: nil)
        
    }
    
}
extension ViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterData = []
        
        if searchText == ""{
            filterData = books
        }
        
        for search in books{
        if search.name.uppercased().contains(searchText.uppercased())
            {
                filterData.append(search)
            }
        }
        tableViewinMain.reloadData()
    }
}
