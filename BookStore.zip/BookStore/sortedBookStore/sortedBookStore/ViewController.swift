//
//  ViewController.swift
//  sortedBookStore
//
//  Created by Abdullah Saeed on 28/01/1444 AH.
//

import UIKit

class ViewController: UIViewController {
    struct Product{
        var name:String
        //outside
      
        //inside top title
        var discrp:String
        //outside
        var price:Int
        //outside
        var category:String
        //outside and inside
        var image:String
        //inside body
       
    }
    var book1 = Product.init(name: "How to Think", discrp:"Thinking skills", price: 90, category: "Learning", image: "Howtothink")
    var book2 = Product.init(name: "Emla", discrp: "Learn how to write in Arabic", price: 10, category: "Strategy", image: "emla")
    var book3 = Product.init(name: "Tahsieli", discrp: "Learning", price: 150, category: "sdaads", image: "tahsi")
    var books:Array<Product> = [Product.init(name: "How to Think", discrp:"Thinking skills", price: 90, category: "Learning", image: "Howtothink"),Product.init(name: "Emla", discrp: "Learn how to write in Arabic", price: 10, category: "Strategy", image: "emla"),Product.init(name: "Tahsieli", discrp: "Learning", price: 150, category: "sdaads", image: "tahsi")]
    


    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableViewinMain: UITableView!
    var filterData:[Product]!
    var sendimagefrom = ""
    var sendSummaryfrom = ""
    var sendNamefrom = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        filterData = books
        tableViewinMain.dataSource = self
        tableViewinMain.delegate = self
        tableViewinMain.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "Cells")
        searchBar.delegate = self
        view.backgroundColor = .lightGray
//        sortTable()
    }
    @IBAction func sortedSegment(_ sender: UISegmentedControl) {
        let selecteSender = sender.selectedSegmentIndex
        
        switch selecteSender {
        case 0:
            filterData.sort(by: {$0.price < $1.price})
        case 1:
            filterData.sort(by: {$0.price > $1.price})
        default:
            break
        }
        tableViewinMain.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as! TableViewCell
        cell.cellImage.image = UIImage(named: "\(filterData[indexPath.row].image)")
        cell.cellPrice.text = "Price: \(filterData[indexPath.row].price)"
        cell.cellname.text = "Name: \(filterData[indexPath.row].name)"
        cell.cellInterest.text = "Interest: \(filterData[indexPath.row].category)"
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showResult"{
            if let send = segue.destination as? secondViewController {
                send.sendimage = sendimagefrom
                send.sendName = sendNamefrom
                send.sendSummry = sendSummaryfrom
            }
        }
    }
    

    
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        sendimagefrom = filterData[indexPath.row].image
        sendNamefrom = filterData[indexPath.row].name
        performSegue(withIdentifier: "showResult", sender: nil)
        
    }
    
}
extension ViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterData = []
        
        if searchText == ""{
            filterData = books
        }
        
        for search in books{
        if search.name.uppercased().contains(searchText.uppercased())
            {
                filterData.append(search)
            }
        }
        tableViewinMain.reloadData()
    }
}
